package com.apsfc.servlet.admin.type;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.apsfc.dao.TypeDao;





@WebServlet("/TypeDelServlet")
public class TypeDelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public TypeDelServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		int id =Integer.parseInt(request.getParameter("id"));
		TypeDao tdao=new TypeDao();
		int flag = tdao.delete(id);
		PrintWriter out = response.getWriter();
		if (flag == -1) {
			out.write("<script>alert('更新失败!');window.navigate('./admin/type.jsp');</script>");
		} else {
			out.write("<script>window.navigate('./admin/type.jsp');</script>");
		}	
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
