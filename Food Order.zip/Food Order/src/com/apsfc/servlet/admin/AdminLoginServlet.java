package com.apsfc.servlet.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.naming.java.javaURLContextFactory;

import javax.servlet.http.Cookie;

import com.apsfc.dao.AdminDao;
import com.apsfc.po.Admin;



@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {



	private static final long serialVersionUID = 1L;


	public AdminLoginServlet() {
		super();
	}


	public void destroy() {
		super.destroy(); 
		
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String name = request.getParameter("name").trim();
		String pwd = request.getParameter("pwd").trim();
		
	AdminDao ad=new AdminDao();
		Admin admin=ad.login(name,pwd);
		if(admin!=null){
			HttpSession session = request.getSession();
			
			session.setAttribute("admin", admin);
			String autologin = "";
			
			autologin = request.getParameter("AutoLogin");
			if (autologin != null || autologin != "") {
				
				Cookie ck1 = new Cookie("name",java.net.URLEncoder.encode(name,"utf-8")); 
				
				Cookie ck2 = new Cookie("pwd", pwd);
				ck1.setMaxAge(60 * 60 * 5*24);
				ck2.setMaxAge(60 * 60 * 5*24);
				response.addCookie(ck1);
				response.addCookie(ck2);
			}
			
			response.sendRedirect("./admin/main.jsp");
		}else{
			PrintWriter out = response.getWriter();
			out.write("<script>alert('用户名或密码错误，请检查您的相关信息!');window.navigate('./admin/index.jsp');</script>");
		}	
	}

	
	public void init() throws ServletException {
		
	}

}
